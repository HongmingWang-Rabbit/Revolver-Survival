import{i as a}from"./DiKfu9P6.js";a();
